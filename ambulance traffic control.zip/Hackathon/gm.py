from gmplot import *
import gmaps
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
import googlemaps

# Requires API key 
gmaps = googlemaps.Client(key='AIzaSyBnAaNV2Xcz030dfCZMh7swYlbjwqYcO_8') 
def getLocation():
    options = Options()
    options.add_argument("--use-fake-ui-for-media-stream")
    timeout = 20
    driver = webdriver.Chrome(executable_path = './chromedriver.exe', chrome_options=options)
    driver.get("https://mycurrentlocation.net/")
    wait = WebDriverWait(driver, timeout)
    longitude = driver.find_elements_by_xpath('//*[@id="longitude"]')
    longitude = [x.text for x in longitude]
    longitude = str(longitude[0])
    latitude = driver.find_elements_by_xpath('//*[@id="latitude"]')
    latitude = [x.text for x in latitude]
    latitude = str(latitude[0])
    driver.quit()
    return (latitude,longitude)
print(getLocation(


gmap1 = gmplot.GoogleMapPlotter(12.823043,80.04592,17) 
gmap1.apikey ='AIzaSyBnAaNV2Xcz030dfCZMh7swYlbjwqYcO_8'

gmap1.marker(12.823043,80.045925,'yellow')
gmap1.marker(12.820864,80.048175,'red')
#gmap1.marker(13.0707,80.1506,'blue')
#gmap1.marker(13.0216,80.1855,'black')



# Pass the absolute path 
 
latti, longi= zip(*[
    (12.823043,80.045925), 
    (12.823034,80.047251),
    (12.821443,80.047241),
    (12.821230,80.047604),
    (12.820864,80.048175)
 #   (37.771096, -122.453889),
  #  (37.768669, -122.453518),
   # (37.766227, -122.460213),
   # (37.764028, -122.510347),
   # (37.771269, -122.511015)
    ])
gmap1.plot(latti, longi, 'cornflowerblue', edge_width=10)

# Scatter points
latti, longi = zip(*[
    (37.769901, -122.498331),
    (37.768645, -122.475328),
    (37.771478, -122.468677),
    (37.769867, -122.466102),
    (37.767187, -122.467496),
    (37.770104, -122.470436)
    ])
gmap1.scatter(latti, longi, '#3B0B39', size=40, marker=False)
gmap1.draw( "map11.html" )