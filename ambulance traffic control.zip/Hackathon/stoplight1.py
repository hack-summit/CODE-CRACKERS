import turtle
import time
import tkinter as tk
wn = turtle.Screen()
wn.title("Stoplight")
wn.bgcolor("black")
x=False

class Stoplight():
	def __init__(self,x,y):
		#Draw the border
		self.pen = turtle.Turtle()
		self.pen.penup()
		self.pen.hideturtle()
		self.pen.speed(0)
		self.pen.color("yellow")
		self.pen.goto(x-30,y+60)
		self.pen.down()
		self.pen.fd(60)
		self.pen.rt(90)
		self.pen.fd(120)
		self.pen.rt(90)
		self.pen.fd(60)
		self.pen.rt(90)
		self.pen.fd(120)
		

		self.color = ""

		self.red_light = turtle.Turtle()
		self.yellow_light = turtle.Turtle()
		self.green_light = turtle.Turtle()

		self.red_light.speed(0)
		self.yellow_light.speed(0)
		self.green_light.speed(0)

		self.red_light.color("grey")
		self.yellow_light.color("grey")
		self.green_light.color("grey")

		self.red_light.shape("circle")
		self.yellow_light.shape("circle")
		self.green_light.shape("circle")

		self.red_light.penup()
		self.yellow_light.penup()
		self.green_light.penup()


		self.red_light.goto(x,y+40)
		self.yellow_light.goto(x,y)
		self.green_light.goto(x,y-40)


	def change_color(self,color):
		
		self.red_light.color("grey")
		self.yellow_light.color("grey")
		self.green_light.color("grey")

		if color == "red":
			self.red_light.color("red")
			self.color = "red"
		elif color == "yellow":
			self.yellow_light.color("yellow")
			self.color = "yellow"
		elif color == "green":
			self.green_light.color("green")
			self.color = "green"
		else:
			print("Error: Unknown Color {}".format(color))

	def timer(self):
		#if self.color == "red":
		#	self.change_color("green")
		#	wn.ontimer(self.timer, 4000)
		#elif self.color =="yellow":
		#	self.change_color("red")
		#	wn.ontimer(self.timer, 4000)
		if self.color == "green":
			self.change_color("yellow")
			wn.ontimer(self.timer, 500)
		
def default():
	stoplight.change_color("yellow")
	stoplight2.change_color("yellow")
	stoplight3.change_color("yellow")
	stoplight4.change_color("yellow")
	

stoplight = Stoplight(-20,-230)
stoplight4 = Stoplight(30,230)
stoplight2 = Stoplight(-200,-10)
stoplight3 = Stoplight(200,40)

def south():
	stoplight.change_color("green")
    #stoplight.timer()
	stoplight4.change_color("red")
	stoplight2.change_color("red")
	stoplight3.change_color("red")
	time.sleep(2)
	#default()

def north():
	stoplight.change_color("red")
	stoplight4.change_color("green")
    #stoplight4.timer()
	stoplight2.change_color("red")
	stoplight3.change_color("red")
	time.sleep(2)
	#default()

def west():
	stoplight.change_color("red")
	stoplight4.change_color("red")
	stoplight2.change_color("green")
    #stoplight2.timer()
	stoplight3.change_color("red")
	time.sleep(2)
	#default()

def east():
	stoplight.change_color("red")
	stoplight4.change_color("red")
	stoplight2.change_color("red")
	stoplight3.change_color("green")
    #stoplight3.timer()
	time.sleep(2)
	#default()
while(1):
    north()
    east()
    south()
    west()

wn.mainloop()    